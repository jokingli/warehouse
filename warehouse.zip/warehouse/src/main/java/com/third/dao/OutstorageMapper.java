package com.third.dao;

import com.third.pojo.Outstorage;

public interface OutstorageMapper {
    int deleteByPrimaryKey(Integer outstorageId);

    int insert(Outstorage record);

    int insertSelective(Outstorage record);

    Outstorage selectByPrimaryKey(Integer outstorageId);

    int updateByPrimaryKeySelective(Outstorage record);

    int updateByPrimaryKey(Outstorage record);
}