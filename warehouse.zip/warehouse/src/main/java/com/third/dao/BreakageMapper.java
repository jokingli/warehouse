package com.third.dao;

import com.third.pojo.Breakage;

public interface BreakageMapper {
    int deleteByPrimaryKey(Integer breakageId);

    int insert(Breakage record);

    int insertSelective(Breakage record);

    Breakage selectByPrimaryKey(Integer breakageId);

    int updateByPrimaryKeySelective(Breakage record);

    int updateByPrimaryKey(Breakage record);
}