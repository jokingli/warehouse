package com.third.dao;

import com.third.pojo.Clireturn;

public interface ClireturnMapper {
    int deleteByPrimaryKey(Integer clireturnId);

    int insert(Clireturn record);

    int insertSelective(Clireturn record);

    Clireturn selectByPrimaryKey(Integer clireturnId);

    int updateByPrimaryKeySelective(Clireturn record);

    int updateByPrimaryKey(Clireturn record);
}