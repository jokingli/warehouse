package com.third.dao;

import com.third.pojo.Allot;

public interface AllotMapper {
    int deleteByPrimaryKey(Integer allotId);

    int insert(Allot record);

    int insertSelective(Allot record);

    Allot selectByPrimaryKey(Integer allotId);

    int updateByPrimaryKeySelective(Allot record);

    int updateByPrimaryKey(Allot record);
}