package com.third.dao;

import com.third.pojo.Instorage;

public interface InstorageMapper {
    int deleteByPrimaryKey(Integer instorageId);

    int insert(Instorage record);

    int insertSelective(Instorage record);

    Instorage selectByPrimaryKey(Integer instorageId);

    int updateByPrimaryKeySelective(Instorage record);

    int updateByPrimaryKey(Instorage record);
}