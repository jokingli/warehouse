package com.third.dao;

import com.third.pojo.Inreturn;

public interface InreturnMapper {
    int deleteByPrimaryKey(Integer inreturnId);

    int insert(Inreturn record);

    int insertSelective(Inreturn record);

    Inreturn selectByPrimaryKey(Integer inreturnId);

    int updateByPrimaryKeySelective(Inreturn record);

    int updateByPrimaryKey(Inreturn record);
}