package com.third.dao;

import com.third.pojo.Product_table;

public interface Product_tableMapper {
    int deleteByPrimaryKey(Integer productId);

    int insert(Product_table record);

    int insertSelective(Product_table record);

    Product_table selectByPrimaryKey(Integer productId);

    int updateByPrimaryKeySelective(Product_table record);

    int updateByPrimaryKey(Product_table record);
}