package com.third.dao;

import com.third.pojo.Provider;

public interface ProviderMapper {
    int deleteByPrimaryKey(Integer providerId);

    int insert(Provider record);

    int insertSelective(Provider record);

    Provider selectByPrimaryKey(Integer providerId);

    int updateByPrimaryKeySelective(Provider record);

    int updateByPrimaryKey(Provider record);
}