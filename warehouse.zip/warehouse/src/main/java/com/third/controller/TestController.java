package com.third.controller;/*
 * @projectName: warehouse
 * @documentName: TestController
 * @author: WJM
 * @date:2020/12/9 15:19
 */

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/ware")
public class TestController {
    @RequestMapping("/test")
    public String test(){
        System.out.println("=====执行了test========》》》");
        return "index";
    }
}
