package com.third.pojo;

import java.util.Date;


//货品调拨

public class Allot {
    private Integer allotId;

    private Date allotDate;

    private String allotCause;

    private Integer allotState;

    private Integer allotDel;

    private String userName;

    private String productName;

    private Integer outwareNum;

    private Integer inwareNum;

    private Integer outwareId;

    private Integer inwareId;

    private String price;

    public Integer getAllotId() {
        return allotId;
    }

    public void setAllotId(Integer allotId) {
        this.allotId = allotId;
    }

    public Date getAllotDate() {
        return allotDate;
    }

    public void setAllotDate(Date allotDate) {
        this.allotDate = allotDate;
    }

    public String getAllotCause() {
        return allotCause;
    }

    public void setAllotCause(String allotCause) {
        this.allotCause = allotCause;
    }

    public Integer getAllotState() {
        return allotState;
    }

    public void setAllotState(Integer allotState) {
        this.allotState = allotState;
    }

    public Integer getAllotDel() {
        return allotDel;
    }

    public void setAllotDel(Integer allotDel) {
        this.allotDel = allotDel;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public Integer getOutwareNum() {
        return outwareNum;
    }

    public void setOutwareNum(Integer outwareNum) {
        this.outwareNum = outwareNum;
    }

    public Integer getInwareNum() {
        return inwareNum;
    }

    public void setInwareNum(Integer inwareNum) {
        this.inwareNum = inwareNum;
    }

    public Integer getOutwareId() {
        return outwareId;
    }

    public void setOutwareId(Integer outwareId) {
        this.outwareId = outwareId;
    }

    public Integer getInwareId() {
        return inwareId;
    }

    public void setInwareId(Integer inwareId) {
        this.inwareId = inwareId;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }
}