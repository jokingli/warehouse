package com.third.pojo;

import java.util.Date;

//供应商
public class Provider {
    private Integer providerId;

    private String providerName;

    private String providerPerson;

    private String providerTel;

    private String providerSite;

    private Date providerDate;

    private Integer providerYear;

    private Integer provideState;

    private Integer providerDel;

    private Integer userId;

    public Integer getProviderId() {
        return providerId;
    }

    public void setProviderId(Integer providerId) {
        this.providerId = providerId;
    }

    public String getProviderName() {
        return providerName;
    }

    public void setProviderName(String providerName) {
        this.providerName = providerName;
    }

    public String getProviderPerson() {
        return providerPerson;
    }

    public void setProviderPerson(String providerPerson) {
        this.providerPerson = providerPerson;
    }

    public String getProviderTel() {
        return providerTel;
    }

    public void setProviderTel(String providerTel) {
        this.providerTel = providerTel;
    }

    public String getProviderSite() {
        return providerSite;
    }

    public void setProviderSite(String providerSite) {
        this.providerSite = providerSite;
    }

    public Date getProviderDate() {
        return providerDate;
    }

    public void setProviderDate(Date providerDate) {
        this.providerDate = providerDate;
    }

    public Integer getProviderYear() {
        return providerYear;
    }

    public void setProviderYear(Integer providerYear) {
        this.providerYear = providerYear;
    }

    public Integer getProvideState() {
        return provideState;
    }

    public void setProvideState(Integer provideState) {
        this.provideState = provideState;
    }

    public Integer getProviderDel() {
        return providerDel;
    }

    public void setProviderDel(Integer providerDel) {
        this.providerDel = providerDel;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }
}