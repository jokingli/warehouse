package com.third.pojo;

import java.util.Date;

//采购入库
public class Instorage {
    private Integer instorageId;

    private Date instorageDate;

    private Integer instorageNum;

    private String instorageRemark;

    private Integer instorageState;

    private Integer instorageDel;

    private String productName;

    private Integer providerId;

    private String factoryName;

    private Integer wareId;

    private String userName;

    private String unit;

    private Integer price;

    private Integer allprice;

    public Integer getInstorageId() {
        return instorageId;
    }

    public void setInstorageId(Integer instorageId) {
        this.instorageId = instorageId;
    }

    public Date getInstorageDate() {
        return instorageDate;
    }

    public void setInstorageDate(Date instorageDate) {
        this.instorageDate = instorageDate;
    }

    public Integer getInstorageNum() {
        return instorageNum;
    }

    public void setInstorageNum(Integer instorageNum) {
        this.instorageNum = instorageNum;
    }

    public String getInstorageRemark() {
        return instorageRemark;
    }

    public void setInstorageRemark(String instorageRemark) {
        this.instorageRemark = instorageRemark;
    }

    public Integer getInstorageState() {
        return instorageState;
    }

    public void setInstorageState(Integer instorageState) {
        this.instorageState = instorageState;
    }

    public Integer getInstorageDel() {
        return instorageDel;
    }

    public void setInstorageDel(Integer instorageDel) {
        this.instorageDel = instorageDel;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public Integer getProviderId() {
        return providerId;
    }

    public void setProviderId(Integer providerId) {
        this.providerId = providerId;
    }

    public String getFactoryName() {
        return factoryName;
    }

    public void setFactoryName(String factoryName) {
        this.factoryName = factoryName;
    }

    public Integer getWareId() {
        return wareId;
    }

    public void setWareId(Integer wareId) {
        this.wareId = wareId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    public Integer getPrice() {
        return price;
    }

    public void setPrice(Integer price) {
        this.price = price;
    }

    public Integer getAllprice() {
        return allprice;
    }

    public void setAllprice(Integer allprice) {
        this.allprice = allprice;
    }
}