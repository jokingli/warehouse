package com.third.pojo;

//货品报损
public class Breakage {
    private Integer breakageId;

    private String breakageProductName;

    private Integer breakageNum;

    private Integer wareId;

    private String breakageUserName;

    private String breakageCause;

    private Integer breakageState;

    private Integer breakageDel;

    public Integer getBreakageId() {
        return breakageId;
    }

    public void setBreakageId(Integer breakageId) {
        this.breakageId = breakageId;
    }

    public String getBreakageProductName() {
        return breakageProductName;
    }

    public void setBreakageProductName(String breakageProductName) {
        this.breakageProductName = breakageProductName;
    }

    public Integer getBreakageNum() {
        return breakageNum;
    }

    public void setBreakageNum(Integer breakageNum) {
        this.breakageNum = breakageNum;
    }

    public Integer getWareId() {
        return wareId;
    }

    public void setWareId(Integer wareId) {
        this.wareId = wareId;
    }

    public String getBreakageUserName() {
        return breakageUserName;
    }

    public void setBreakageUserName(String breakageUserName) {
        this.breakageUserName = breakageUserName;
    }

    public String getBreakageCause() {
        return breakageCause;
    }

    public void setBreakageCause(String breakageCause) {
        this.breakageCause = breakageCause;
    }

    public Integer getBreakageState() {
        return breakageState;
    }

    public void setBreakageState(Integer breakageState) {
        this.breakageState = breakageState;
    }

    public Integer getBreakageDel() {
        return breakageDel;
    }

    public void setBreakageDel(Integer breakageDel) {
        this.breakageDel = breakageDel;
    }
}