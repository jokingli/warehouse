package com.third.pojo;

//仓库
public class Ware {
    private Integer wareId;

    private Integer userId;

    private String wareName;

    private String wareType;

    private Integer wareNum;

    private Integer wareNumMax;

    private Integer wareState;

    private Integer wareDel;

    public Integer getWareId() {
        return wareId;
    }

    public void setWareId(Integer wareId) {
        this.wareId = wareId;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public String getWareName() {
        return wareName;
    }

    public void setWareName(String wareName) {
        this.wareName = wareName;
    }

    public String getWareType() {
        return wareType;
    }

    public void setWareType(String wareType) {
        this.wareType = wareType;
    }

    public Integer getWareNum() {
        return wareNum;
    }

    public void setWareNum(Integer wareNum) {
        this.wareNum = wareNum;
    }

    public Integer getWareNumMax() {
        return wareNumMax;
    }

    public void setWareNumMax(Integer wareNumMax) {
        this.wareNumMax = wareNumMax;
    }

    public Integer getWareState() {
        return wareState;
    }

    public void setWareState(Integer wareState) {
        this.wareState = wareState;
    }

    public Integer getWareDel() {
        return wareDel;
    }

    public void setWareDel(Integer wareDel) {
        this.wareDel = wareDel;
    }
}