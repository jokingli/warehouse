package com.third.pojo;

import java.util.Date;

//客户退货
public class Clireturn {
    private Integer clireturnId;

    private Date clireturnDate;

    private Integer clireturnNum;

    private String clireturnCause;

    private Integer clireturnAllprice;

    private Integer clireturnState;

    private Integer clireturnDel;

    private Integer outstorageId;

    public Integer getClireturnId() {
        return clireturnId;
    }

    public void setClireturnId(Integer clireturnId) {
        this.clireturnId = clireturnId;
    }

    public Date getClireturnDate() {
        return clireturnDate;
    }

    public void setClireturnDate(Date clireturnDate) {
        this.clireturnDate = clireturnDate;
    }

    public Integer getClireturnNum() {
        return clireturnNum;
    }

    public void setClireturnNum(Integer clireturnNum) {
        this.clireturnNum = clireturnNum;
    }

    public String getClireturnCause() {
        return clireturnCause;
    }

    public void setClireturnCause(String clireturnCause) {
        this.clireturnCause = clireturnCause;
    }

    public Integer getClireturnAllprice() {
        return clireturnAllprice;
    }

    public void setClireturnAllprice(Integer clireturnAllprice) {
        this.clireturnAllprice = clireturnAllprice;
    }

    public Integer getClireturnState() {
        return clireturnState;
    }

    public void setClireturnState(Integer clireturnState) {
        this.clireturnState = clireturnState;
    }

    public Integer getClireturnDel() {
        return clireturnDel;
    }

    public void setClireturnDel(Integer clireturnDel) {
        this.clireturnDel = clireturnDel;
    }

    public Integer getOutstorageId() {
        return outstorageId;
    }

    public void setOutstorageId(Integer outstorageId) {
        this.outstorageId = outstorageId;
    }
}