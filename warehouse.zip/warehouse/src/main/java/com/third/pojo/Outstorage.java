package com.third.pojo;

import java.util.Date;

//出库
public class Outstorage {
    private Integer outstorageId;

    private Integer outstorageNum;

    private Date outstorageDate;

    private String outstorageRemark;

    private Integer outstorageState;

    private Integer outstorageDel;

    private String productName;

    private Integer clientId;

    private String unit;

    private Integer wareId;

    private Integer price;

    private Integer allprice;

    public Integer getOutstorageId() {
        return outstorageId;
    }

    public void setOutstorageId(Integer outstorageId) {
        this.outstorageId = outstorageId;
    }

    public Integer getOutstorageNum() {
        return outstorageNum;
    }

    public void setOutstorageNum(Integer outstorageNum) {
        this.outstorageNum = outstorageNum;
    }

    public Date getOutstorageDate() {
        return outstorageDate;
    }

    public void setOutstorageDate(Date outstorageDate) {
        this.outstorageDate = outstorageDate;
    }

    public String getOutstorageRemark() {
        return outstorageRemark;
    }

    public void setOutstorageRemark(String outstorageRemark) {
        this.outstorageRemark = outstorageRemark;
    }

    public Integer getOutstorageState() {
        return outstorageState;
    }

    public void setOutstorageState(Integer outstorageState) {
        this.outstorageState = outstorageState;
    }

    public Integer getOutstorageDel() {
        return outstorageDel;
    }

    public void setOutstorageDel(Integer outstorageDel) {
        this.outstorageDel = outstorageDel;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public Integer getClientId() {
        return clientId;
    }

    public void setClientId(Integer clientId) {
        this.clientId = clientId;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    public Integer getWareId() {
        return wareId;
    }

    public void setWareId(Integer wareId) {
        this.wareId = wareId;
    }

    public Integer getPrice() {
        return price;
    }

    public void setPrice(Integer price) {
        this.price = price;
    }

    public Integer getAllprice() {
        return allprice;
    }

    public void setAllprice(Integer allprice) {
        this.allprice = allprice;
    }
}