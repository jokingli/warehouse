package com.third.pojo;

import java.util.Date;

//采购退货
public class Inreturn {
    private Integer inreturnId;

    private Date inreturnDate;

    private String inreturnCause;

    private Integer inreturnNum;

    private Integer inreturnAllprice;

    private Integer inreturnState;

    private Integer inreturnDel;

    private Integer instorageId;

    public Integer getInreturnId() {
        return inreturnId;
    }

    public void setInreturnId(Integer inreturnId) {
        this.inreturnId = inreturnId;
    }

    public Date getInreturnDate() {
        return inreturnDate;
    }

    public void setInreturnDate(Date inreturnDate) {
        this.inreturnDate = inreturnDate;
    }

    public String getInreturnCause() {
        return inreturnCause;
    }

    public void setInreturnCause(String inreturnCause) {
        this.inreturnCause = inreturnCause;
    }

    public Integer getInreturnNum() {
        return inreturnNum;
    }

    public void setInreturnNum(Integer inreturnNum) {
        this.inreturnNum = inreturnNum;
    }

    public Integer getInreturnAllprice() {
        return inreturnAllprice;
    }

    public void setInreturnAllprice(Integer inreturnAllprice) {
        this.inreturnAllprice = inreturnAllprice;
    }

    public Integer getInreturnState() {
        return inreturnState;
    }

    public void setInreturnState(Integer inreturnState) {
        this.inreturnState = inreturnState;
    }

    public Integer getInreturnDel() {
        return inreturnDel;
    }

    public void setInreturnDel(Integer inreturnDel) {
        this.inreturnDel = inreturnDel;
    }

    public Integer getInstorageId() {
        return instorageId;
    }

    public void setInstorageId(Integer instorageId) {
        this.instorageId = instorageId;
    }
}