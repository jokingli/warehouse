package com.third.pojo;

import java.util.Date;

//客户
public class Client {
    private Integer clientId;

    private String clientName;

    private String clientPerson;

    private String clientTel;

    private String clientSite;

    private Date clientDate;

    private Integer clientYear;

    private Integer clientState;

    private Integer clientDel;

    public Integer getClientId() {
        return clientId;
    }

    public void setClientId(Integer clientId) {
        this.clientId = clientId;
    }

    public String getClientName() {
        return clientName;
    }

    public void setClientName(String clientName) {
        this.clientName = clientName;
    }

    public String getClientPerson() {
        return clientPerson;
    }

    public void setClientPerson(String clientPerson) {
        this.clientPerson = clientPerson;
    }

    public String getClientTel() {
        return clientTel;
    }

    public void setClientTel(String clientTel) {
        this.clientTel = clientTel;
    }

    public String getClientSite() {
        return clientSite;
    }

    public void setClientSite(String clientSite) {
        this.clientSite = clientSite;
    }

    public Date getClientDate() {
        return clientDate;
    }

    public void setClientDate(Date clientDate) {
        this.clientDate = clientDate;
    }

    public Integer getClientYear() {
        return clientYear;
    }

    public void setClientYear(Integer clientYear) {
        this.clientYear = clientYear;
    }

    public Integer getClientState() {
        return clientState;
    }

    public void setClientState(Integer clientState) {
        this.clientState = clientState;
    }

    public Integer getClientDel() {
        return clientDel;
    }

    public void setClientDel(Integer clientDel) {
        this.clientDel = clientDel;
    }
}